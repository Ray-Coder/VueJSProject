<template>
  <div id="app">
    <img height="350px" src="./assets/logo.jpg">
    <h1>{{ msg }}</h1>
    <chart></chart>
    <treeMaps></treeMaps>
  </div>  
</template>

<script>
import chart from './Chart.vue'
import treeMaps from './Tree.vue'
import Vue from 'vue'

export default {
  name: 'app',
  data () {
    return {
      msg: 'Welcome to your Tech Stack dashboard'
    }
  },
  components: {
    chart,
    treeMaps
  }
}
</script>

<style lang="scss">
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

h1, h2 {
  font-weight: normal;
}


a {
  color: #42b983;
}
</style>
